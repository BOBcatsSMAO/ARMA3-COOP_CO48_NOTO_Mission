class JSHK_patrols
{
	tag = "JSHK";
	class Patrol
	{
		file = "JSHK_fncs";
		class patrols {};
		class deleteOldAO {};
	};
};